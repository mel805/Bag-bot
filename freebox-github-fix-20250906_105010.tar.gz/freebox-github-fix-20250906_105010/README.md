# 🔧 Package de Correction GitHub - BAG Discord Bot

## 🎯 Objectif

Ce package corrige le problème de sauvegarde GitHub sur Freebox :
```
❌ Sauvegarde GitHub: Erreur requête
GitHub: Dépôt 'mel805/Bag-bot' introuvable ou branche 'backu'
```

## 📦 Contenu du Package

- `install.sh` - Script d'installation automatique
- `fix-github-freebox.sh` - Correction complète GitHub
- `fix-branch-name.sh` - Correction spécialisée branche
- `fix-github-config.js` - Test et correction Node.js
- `.env.example` - Exemple de configuration
- `FREEBOX_DEPLOY_INSTRUCTIONS.md` - Instructions détaillées
- `FREEBOX_GITHUB_FIX.md` - Guide de dépannage

## 🚀 Installation Rapide

```bash
# 1. Transférez ce package sur votre Freebox
# 2. Exécutez l'installation :
sudo ./install.sh

# 3. Configurez vos tokens :
nano /home/botuser/bag-discord-bot/.env

# 4. Corrigez le problème :
sudo /home/botuser/bag-discord-bot/scripts/fix-branch-name.sh

# 5. Redémarrez le bot :
sudo systemctl restart bag-discord-bot
```

## ✅ Résultat Attendu

Après correction, votre bot affichera :
- ✅ Sauvegarde Locale : Fichier créé
- ✅ Sauvegarde GitHub : Sauvegarde réussie sur branche backup-data

---

*Package créé pour résoudre le problème GitHub sur Freebox*
